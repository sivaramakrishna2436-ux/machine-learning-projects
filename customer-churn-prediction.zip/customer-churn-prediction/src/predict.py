"""
Predict churn for a new customer.
Run from the project root:
    python src/predict.py
"""
from pathlib import Path
import joblib
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = ROOT / "models" / "churn_pipeline.joblib"

def main():
    if not MODEL_PATH.exists():
        raise FileNotFoundError("Model not found. First run: python src/train_model.py")

    model = joblib.load(MODEL_PATH)
    new_customer = pd.DataFrame([{
        "tenure_months": 4,
        "monthly_charges": 95.0,
        "support_calls": 5,
        "contract_type": "Month-to-month",
        "internet_service": "Fiber optic"
    }])

    prediction = int(model.predict(new_customer)[0])
    probability = float(model.predict_proba(new_customer)[0][1])

    print("Customer Churn Prediction")
    print("-------------------------")
    print("Prediction:", "Likely to churn" if prediction == 1 else "Not likely to churn")
    print(f"Churn probability: {probability:.1%}")

if __name__ == "__main__":
    main()
