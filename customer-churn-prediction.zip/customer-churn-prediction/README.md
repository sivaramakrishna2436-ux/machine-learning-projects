# Customer Churn Prediction

An end-to-end beginner-friendly Machine Learning project that predicts whether a telecom customer may leave a service.

## Project overview
- **Problem:** Identify customers who may churn so a business can plan retention actions.
- **Approach:** Binary classification using Logistic Regression.
- **Data:** 500 rows of fully synthetic customer data. No real customer or company information is used.
- **Features:** Customer tenure, monthly charges, support calls, contract type, and internet service.
- **Target:** `churn` (`1` = churn, `0` = stay).

> This is a learning/demo project. The synthetic data and evaluation results are not suitable for real business decisions.

## Project structure

```text
customer-churn-prediction/
├── data/
│   └── customer_churn.csv
├── src/
│   ├── train_model.py
│   └── predict.py
├── models/                 # created after training
├── README.md
├── requirements.txt
└── .gitignore
```

## Run online with Google Colab (no local Python installation)

1. Open [Google Colab](https://colab.research.google.com/).
2. Choose **File → Upload notebook** only if you have a notebook. For this project ZIP, use the Colab file browser upload or upload the ZIP to Google Drive and mount Drive.
3. Upload `customer-churn-prediction.zip` into the Colab session, then run:

```python
from google.colab import files
uploaded = files.upload()  # select customer-churn-prediction.zip

import zipfile
with zipfile.ZipFile("customer-churn-prediction.zip", "r") as z:
    z.extractall("/content")

%cd /content/customer-churn-prediction
!pip install -r requirements.txt
!python src/train_model.py
!python src/predict.py
```

Google Colab already includes many common data-science packages. The install command ensures the listed project dependencies are present.

## Run locally (optional)

```bash
pip install -r requirements.txt
python src/train_model.py
python src/predict.py
```

## Outputs
After training, the project creates:
- `models/churn_pipeline.joblib` — trained preprocessing + model pipeline
- `models/metrics.json` — evaluation metrics on the held-out test set

## Skills demonstrated
Python, Pandas, scikit-learn, data preprocessing, categorical encoding, feature scaling, train/test split, classification, model evaluation, model serialization, and inference.

## Next improvements
- Add exploratory data analysis and visualizations.
- Compare Logistic Regression with Random Forest and Gradient Boosting.
- Add cross-validation and threshold tuning.
- Build a FastAPI prediction endpoint and a simple Streamlit UI.
